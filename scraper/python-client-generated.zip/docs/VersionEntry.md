# VersionEntry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**major_version** | **int** |  | [optional] 
**minor_version** | **int** |  | [optional] 
**revision_type** | **str** |  | [optional] 
**revision_date** | **date** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

